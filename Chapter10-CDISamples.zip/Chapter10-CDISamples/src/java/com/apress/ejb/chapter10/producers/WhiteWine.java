package com.apress.ejb.chapter10.producers;

class WhiteWine implements Wine {
   public String getColor() {
       return "White";
   }
}
