package com.apress.ejb.chapter10.anyqualifier;

@White
class WhiteWine implements Wine {
   public String getColor() {
       return "White";
   }
}
