package com.apress.ejb.chapter10.producers;

interface Wine {
   public String getColor();
}
