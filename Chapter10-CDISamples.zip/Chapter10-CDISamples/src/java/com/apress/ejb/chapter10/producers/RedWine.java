package com.apress.ejb.chapter10.producers;

class RedWine implements Wine {
   public String getColor() {
       return "Red";
   }
}
