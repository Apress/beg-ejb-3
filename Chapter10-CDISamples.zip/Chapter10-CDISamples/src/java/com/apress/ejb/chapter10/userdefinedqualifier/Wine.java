package com.apress.ejb.chapter10.userdefinedqualifier;

interface Wine {
   public String getColor();
}
