package com.apress.ejb.chapter10.alternatives;

interface Wine {
   public String getColor();
}
