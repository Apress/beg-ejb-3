package com.apress.ejb.chapter10.anyqualifier;

interface Wine {
   public String getColor();
}
