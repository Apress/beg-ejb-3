package com.apress.ejb.chapter10.producers;

class SparklingWine implements Wine {
   public String getColor() {
       return "Sparkling";
   }
}
